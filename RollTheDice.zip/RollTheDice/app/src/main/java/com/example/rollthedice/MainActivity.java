package com.example.rollthedice;

import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Button;
import java.util.ArrayList;

/**
 * MainActivity holds the thread that prints the face of dices.
 */
public class MainActivity extends AppCompatActivity {

    static ArrayList<ImageView> views = new ArrayList<>();
    static ArrayList<Drawable> images  = new ArrayList<>();

    /**
     * Protected void onCreate is called once the app is pulled.
     * This class makes the images and calls the thread later in the class.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Adds the ImageView to
        ImageView oneImage = findViewById(R.id.one);
        ImageView twoImage = findViewById(R.id.two);
        ImageView threeImage = findViewById(R.id.three);
        ImageView fourImage = findViewById(R.id.four);
        ImageView fiveImage = findViewById(R.id.five);

        //  adding each image to a view.
        views.add(oneImage);
        views.add(twoImage);
        views.add(threeImage);
        views.add(fourImage);
        views.add(fiveImage);

        //ArrayList<Drawable> image = new ArrayList<>();

        // Adds the drawables variables to images.
        images.add(getDrawable(R.drawable.die_one));
        images.add(getDrawable(R.drawable.die_two));
        images.add(getDrawable(R.drawable.die_three));
        images.add(getDrawable(R.drawable.die_four));
        images.add(getDrawable(R.drawable.die_five));

        final newLabels[] dice = new newLabels[5];
        for (int i = 0; i < dice.length; i++) {
            dice[i] = new newLabels(this,views.get(i));
        }

        // Makes the button component to roll the dice.
        Button button = findViewById(R.id.button);

        /**
         * SetOnClickListener gets called once the button is pushed
         */
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                // goes through through the size of view class and makes 5 threads.
                for (int i = 0; i < views.size(); i++) {
                    Thread d = new Thread(dice[i]);
                    d.start();
                    try {   // makes sure the thread is done
                        Thread.sleep(100);
                    } catch (InterruptedException e1) {
                        System.out.println("a;skdlfha;skldfja;sfj");
                    }
                }
            }
        });


    }
}
