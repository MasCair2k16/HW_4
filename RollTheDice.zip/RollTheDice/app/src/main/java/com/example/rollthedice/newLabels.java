package com.example.rollthedice;

import android.widget.ImageView;

public class newLabels implements Runnable {

    ImageView diceFace;
    MainActivity activity;

    /**
     * This constructor is made to set the Image view in the thread and to
     * set the MainActivity as an object so the images can be called
     * @param a is the activity
     * @param i is the imageView
     */
    newLabels(MainActivity a, ImageView i) {
        activity = a;
        diceFace = i;
    }

    /**
     * The thread that gets called from {MainActivity}.
     */
    @Override
    public void run() {
        int rolls = (int) (Math.random() * 10) + 5; // randomizes the number of rolls
        //int d = 0;
        for (int i = 0; i < rolls; i++) { // for the amount of rolls,rand numbers will then be used to pick dice
            activity.runOnUiThread(new Runnable() {
                public void run() {
                    //d = ((int) (Math.random() * 5)) + 1;
                    diceFace.setImageDrawable(MainActivity.images.get(((int) (Math.random() * 4)) + 1));
                }
            });

            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                System.out.println("You met here");
            }

        }
    }
}

